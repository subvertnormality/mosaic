import ast,hashlib,json
from pathlib import Path
OLD='924cf69c0c32ce6e06657587585ed893ba72ce5af5ee288a5a3b4fbf81e47007'
REPORT='f36318c05f2ec7ed0abc8293a683f0867f8a2eb0f394e0092501d770325ee9d0'
RECEIPT='05c1aef1a084077bd9d0d13d1d18b3bb6c3295c7b17fb0450674707bc5d0b47b'
OLD_PROFILES='7d14274813022d9bf29b128cb7c1f01a95982bbf3ad76aeff7999e7d8db4c841'
OLD_SCHEMA='6e892b200455e1b5190fd50b7c53b82b4f8a215d5e8d75263dcda5e759aa2d6c'
OLD_SCENES='ae599085b1e45e616da601c7cf0a579103f7e94ff6af885267eea7a99e0ebdea'
OLD_IDS=['oilcan-pocket','bass-and-intervals','three-voice-conversation','ghost-note-comparison','scale-slot-comparison','swing-comparison','note-merge-modes','polymeter']
class Reject(ValueError):pass
def need(x,m):
 if not x:raise Reject(m)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def astfile(p):return ast.parse(Path(p).read_text())
def d(x):return ast.dump(x,include_attributes=False)
def init(t):
 c=[n for n in t.body if isinstance(n,ast.ClassDef) and n.name=='Driver'];need(len(c)==1,'Driver class count')
 f=[n for n in c[0].body if isinstance(n,ast.FunctionDef) and n.name=='__init__'];need(len(f)==1,'Driver init count');return f[0]
def prove(oldpath,newpath,oldprof,newprof,oldschema,newschema,origin,report,receipt):
 need(sha(oldpath)==OLD and sha(origin)==OLD,'historical Driver bytes changed')
 need(sha(report)==REPORT and sha(receipt)==RECEIPT,'historical report/qualification changed')
 old=astfile(oldpath);new=astfile(newpath)
 need(sha(oldprof)==OLD_PROFILES,'historical output-profiles baseline changed')
 op=json.loads(Path(oldprof).read_text())['profiles'];np=json.loads(Path(newprof).read_text())['profiles'];need(op==np,'output-profiles changed')
 const=[n for n in new.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='MANUAL_PLAYER_UI_PROFILE' for t in n.targets)]
 fun=[n for n in new.body if isinstance(n,ast.FunctionDef) and n.name=='validate_profile_clock']
 need(len(const)==1 and len(fun)==1,'new profile constant/helper missing or duplicated')
 try: val=ast.literal_eval(const[0].value)
 except (ValueError,TypeError,MemoryError,RecursionError): raise Reject('new profile constant is not a safe literal')
 need(val=={'controlled_ui_only':True,'mods':op['manual-trio']['mods']},'new voice pins differ from exact manual-trio pins')
 expected=ast.parse('''def validate_profile_clock(profile, clock_mode, output_profiles):
 if profile == "manual-player-ui":
  if clock_mode != "controlled-experimental": raise ValueError("manual-player-ui is controlled UI-only")
 elif profile in output_profiles and clock_mode != "real-time": raise ValueError("Audio/Crow profiles require real time; DSP and Crow are not controlled-time sources")
''').body[0]
 need(d(fun[0])==d(expected),'profile clock policy differs')
 polns={};exec(compile(ast.Module(body=[fun[0]],type_ignores=[]),'<clock-policy>','exec'),polns); clock_policy=polns['validate_profile_clock']
 for name in op:
  clock_policy(name,'real-time',op)
  try:clock_policy(name,'controlled-experimental',op)
  except ValueError:pass
  else:raise Reject('legacy output profile lost its controlled-time rejection: '+name)
 for name in ('base-midi','midi-modulation'):
  for mode in ('real-time','controlled-experimental'):clock_policy(name,mode,op)
 clock_policy('manual-player-ui','controlled-experimental',op)
 try:clock_policy('manual-player-ui','real-time',op)
 except ValueError:pass
 else:raise Reject('UI profile accepted real-time mode')
 # Legacy behavior matrix: every prior profile remains realtime/capability gated; base profiles remain ungated.
 for name in op:
  need(name in np and op[name]==np[name],'legacy output profile changed: '+name)
  need(name!='manual-player-ui','new profile collision')
 # Remove only the exact additions, specialize new dispatch to old predicates, then demand full-module AST equality.
 body=[n for n in new.body if n is not const[0] and n is not fun[0]]
 norm=ast.Module(body=body,type_ignores=[]);f=init(norm)
 call=ast.parse('validate_profile_clock(profile,clock_mode,output_profiles)',mode='eval').body
 clock=ast.parse("if profile in output_profiles and clock_mode!='real-time':"+chr(10)+" raise ValueError('Audio/Crow profiles require real time; DSP and Crow are not controlled-time sources')").body[0]
 hits=[i for i,n in enumerate(f.body) if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and d(n.value)==d(call)]
 need(len(hits)==1,'clock policy call differs');f.body[hits[0]]=clock
 ass=[n for n in f.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='manual_player_ui' for t in n.targets)]
 need(len(ass)==1 and d(ass[0].value)==d(ast.parse("profile == 'manual-player-ui'",mode='eval').body),'profile selector differs');f.body.remove(ass[0])
 tuple_nodes=[n for n in ast.walk(f) if isinstance(n,ast.Tuple) and d(n)==d(ast.parse("('base-midi','midi-modulation','manual-player-ui')",mode='eval').body)]
 need(len(tuple_nodes)==1,'recognized-profile tuple delta must occur exactly once')
 tuple_nodes[0].elts=tuple_nodes[0].elts[:-1]
 oldmods=ast.parse("output_profiles[profile]['mods'] if profile in output_profiles else json.loads((REPO/'tests/behaviour/mods.lock.json').read_text())['mods']",mode='eval').body
 newmods=ast.parse("MANUAL_PLAYER_UI_PROFILE['mods'] if manual_player_ui else output_profiles[profile]['mods'] if profile in output_profiles else json.loads((REPO/'tests/behaviour/mods.lock.json').read_text())['mods']",mode='eval').body
 m=0
 for n in ast.walk(f):
  if isinstance(n,ast.IfExp) and d(n)==d(newmods):n.test=oldmods.test;n.body=oldmods.body;n.orelse=oldmods.orelse;m+=1
 need(m==1,'mod dispatch delta differs')
 oldtest=ast.parse('profile in output_profiles',mode='eval').body
 newtest=ast.parse('profile in output_profiles or manual_player_ui',mode='eval').body
 k=0
 for n in ast.walk(f):
  if isinstance(n,ast.If) and d(n.test)==d(newtest):n.test=oldtest;k+=1
 need(k==2,'origin/ignored-source guard delta differs')
 need(d(old)==d(norm),'unrelated Driver AST change')
 # Bind the historical eight examples to their frozen recipe/profile and actual capture clock.
 scenes=Path(__file__).resolve().parents[1]/'origin-audio-scenes.yaml'
 need(sha(scenes)==OLD_SCENES,'frozen audio scene source changed')
 import yaml
 rows={v['id']:v for v in yaml.safe_load(scenes.read_text())['examples']}
 need(set(OLD_IDS)<=set(rows),'frozen recipe lost a reused example')
 need(all(rows[i].get('profile')=='manual-trio' for i in OLD_IDS),'old capture profile differs from manual-trio')
 # Only schema change allowed is enabling existing manual-trio plus new UI profile names.
 need(sha(oldschema)==OLD_SCHEMA,'historical case-scene schema baseline changed')
 a=json.loads(Path(oldschema).read_text());b=json.loads(Path(newschema).read_text());keys=('properties','scenes','items','properties','profile','enum')
 def get(x):
  for key in keys:x=x[key]
  return x
 ae=get(a);be=get(b);need(be==ae+['manual-player-ui'],'scene-profile schema enum delta differs')
 c=json.loads(json.dumps(b));q=c
 for key in keys[:-1]:q=q[key]
 q['enum']=ae;need(c==a,'unrelated schema change')
 r=json.loads(Path(report).read_text());z=json.loads(Path(receipt).read_text())
 need(r.get('passed') is False and r.get('complete_regression_run') is False and r.get('harness_sha256',{}).get('driver.py')==OLD,'origin report was changed/relabelled')
 need(r.get('audio_capture_clock_mode')=='real-time','old musical captures are not pinned as real-time')
 rz=z.get('result',{});need(z.get('origin_report_sha256')==REPORT and rz.get('all_inventory_captured') is False and rz.get('all_pass') is False and rz.get('complete_regression_run') is False,'old8 receipt was changed/relabelled')
 return {'passed':True,'kind':'historical-audio-driver-source-equivalence','old_driver_sha256':sha(oldpath),'new_driver_sha256':sha(newpath),'old_profiles_sha256':sha(oldprof),'new_profiles_sha256':sha(newprof),'old_schema_sha256':sha(oldschema),'new_schema_sha256':sha(newschema),'candidate_patch_sha256':sha(Path(__file__).resolve().parents[1]/'candidate.patch'),'claim':'only manual-player-ui dispatch is added; specializing it away yields complete historical Driver AST','old8_origin_driver_sha256':OLD,'origin_report_sha256':REPORT,'old8_receipt_sha256':RECEIPT,'old_examples':8,'old_wavs':22,'deferred_examples':13,'deferred_wavs':32,'historical_completion_flags':False,'old_scene_source_sha256':OLD_SCENES,'old_example_ids':OLD_IDS,'old_profile':'manual-trio','old_audio_capture_clock':'real-time','profile_policy_matrix':'all existing output profiles plus base-midi and midi-modulation tested'}

if __name__=="__main__":
 root=Path(__file__).resolve().parents[1]
 result=prove(root/"old/tests/behaviour/driver.py",root/"candidate/tests/behaviour/driver.py",root/"old/tests/behaviour/output-profiles.json",root/"candidate/tests/behaviour/output-profiles.json",root/"old/manual/case-scenes.schema.json",root/"candidate/manual/case-scenes.schema.json",root/"origin-driver.py",root/"origin-report.json",root/"origin8-receipt.json")
 dest=root/"source-equivalence-receipt.json"
 dest.write_text(json.dumps(result,indent=2,sort_keys=True)+chr(10))
 print(json.dumps(result,indent=2))
