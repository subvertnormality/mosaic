import json,tempfile,unittest
from pathlib import Path
from driver_compat_proof import Reject,prove
B=Path(__file__).resolve().parents[1]; O=B/'old/tests/behaviour/driver.py';N=B/'candidate/tests/behaviour/driver.py';OP=B/'old/tests/behaviour/output-profiles.json';NP=B/'candidate/tests/behaviour/output-profiles.json';OS=B/'old/manual/case-scenes.schema.json';NS=B/'candidate/manual/case-scenes.schema.json';OR=B/'origin-driver.py';R=B/'origin-report.json';Q=B/'origin8-receipt.json'
def go(o=O,n=N,op=OP,np=NP,os=OS,ns=NS,or_=OR,r=R,q=Q):return prove(o,n,op,np,os,ns,or_,r,q)
class Tests(unittest.TestCase):
 def test_sealed_candidate(self):self.assertTrue(go()['passed'])
 def test_unrelated_driver_edit(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'x.py';p.write_text(N.read_text().replace('self.profile=profile;self.mod_revisions={};self.applied_mod_patches={}','self.profile=profile;self.mod_revisions={};self.applied_mod_patches={};self.extra=True'))
   with self.assertRaises(Reject):go(n=p)
 def test_clock_gate_edit(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'x.py';p.write_text(N.read_text().replace('controlled-experimental','real-time'))
   with self.assertRaises(Reject):go(n=p)
 def test_voice_pin_edit(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'x.py';p.write_text(N.read_text().replace('8729b9ceee71d2b07067e89fbef5d8b98d6a0c89','0'*40))
   with self.assertRaises(Reject):go(n=p)
 def test_output_profiles_edit(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'x.json';v=json.loads(NP.read_text());v['profiles']['manual-trio']['capabilities'].append('fake');p.write_text(json.dumps(v))
   with self.assertRaises(Reject):go(np=p)
 def test_schema_extra_edit(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'x.json';v=json.loads(NS.read_text());v['$comment']='extra';p.write_text(json.dumps(v))
   with self.assertRaises(Reject):go(ns=p)
 def test_old_driver_edit(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'x.py';p.write_text(OR.read_text()+'\n# altered');
   with self.assertRaises(Reject):go(or_=p)
 def test_old_report_edit(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'x.json';p.write_text(R.read_text()+' ')
   with self.assertRaises(Reject):go(r=p)

 def test_paired_profile_baseline_and_candidate_mutation_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   op=Path(d)/'old.json';np=Path(d)/'new.json';a=json.loads(OP.read_text());b=json.loads(NP.read_text());a['profiles']['manual-trio']['capabilities'].append('forged');b['profiles']['manual-trio']['capabilities'].append('forged');op.write_text(json.dumps(a));np.write_text(json.dumps(b))
   with self.assertRaises(Reject):go(op=op,np=np)
 def test_paired_schema_baseline_and_candidate_mutation_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   os=Path(d)/'old.json';ns=Path(d)/'new.json';a=json.loads(OS.read_text());b=json.loads(NS.read_text());a['$comment']='forged';b['$comment']='forged';os.write_text(json.dumps(a));ns.write_text(json.dumps(b))
   with self.assertRaises(Reject):go(os=os,ns=ns)
 def test_executable_profile_constant_rejected(self):
  import ast
  with tempfile.TemporaryDirectory() as d:
   source=N.read_text(); tree=ast.parse(source)
   node=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='MANUAL_PLAYER_UI_PROFILE' for t in n.targets))
   value=ast.literal_eval(node.value)
   segment=ast.get_source_segment(source,node)
   replacement='MANUAL_PLAYER_UI_PROFILE = dict(controlled_ui_only=True, mods='+repr(value['mods'])+')'
   p=Path(d)/'driver.py';p.write_text(source.replace(segment,replacement,1))
   with self.assertRaises(Reject):go(n=p)

 def test_recognized_profile_tuple_match_must_be_unique(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'x.py';p.write_text(N.read_text().replace("('base-midi','midi-modulation','manual-player-ui')","('base-midi','midi-modulation','manual-player-ui','manual-player-ui')"))
   with self.assertRaises(Reject):go(n=p)
